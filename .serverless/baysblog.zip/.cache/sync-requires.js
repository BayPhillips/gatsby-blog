const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---node-modules-gatsby-plugin-offline-app-shell-js": hot(preferDefault(require("/mnt/c/Users/Bay/shareddev/gatsby-blog/node_modules/gatsby-plugin-offline/app-shell.js"))),
  "component---src-templates-contentful-page-js": hot(preferDefault(require("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/templates/contentfulPage.js"))),
  "component---src-templates-blog-post-listing-js": hot(preferDefault(require("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/templates/blogPostListing.js"))),
  "component---src-templates-blog-post-js": hot(preferDefault(require("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/templates/blogPost.js"))),
  "component---src-pages-404-js": hot(preferDefault(require("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/pages/404.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/pages/index.js")))
}

