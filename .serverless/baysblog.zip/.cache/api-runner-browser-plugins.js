module.exports = [{
      plugin: require('/mnt/c/Users/Bay/shareddev/gatsby-blog/node_modules/gatsby-plugin-google-analytics/gatsby-browser'),
      options: {"plugins":[],"trackingId":"UA-15538345-1","head":false},
    },{
      plugin: require('/mnt/c/Users/Bay/shareddev/gatsby-blog/node_modules/gatsby-plugin-canonical-urls/gatsby-browser'),
      options: {"plugins":[],"siteUrl":"https://www.bayphillips.com"},
    },{
      plugin: require('/mnt/c/Users/Bay/shareddev/gatsby-blog/node_modules/gatsby-plugin-offline/gatsby-browser'),
      options: {"plugins":[]},
    },{
      plugin: require('/mnt/c/Users/Bay/shareddev/gatsby-blog/node_modules/gatsby-plugin-catch-links/gatsby-browser'),
      options: {"plugins":[]},
    }]
