// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---node-modules-gatsby-plugin-offline-app-shell-js": () => import("/mnt/c/Users/Bay/shareddev/gatsby-blog/node_modules/gatsby-plugin-offline/app-shell.js" /* webpackChunkName: "component---node-modules-gatsby-plugin-offline-app-shell-js" */),
  "component---src-templates-contentful-page-js": () => import("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/templates/contentfulPage.js" /* webpackChunkName: "component---src-templates-contentful-page-js" */),
  "component---src-templates-blog-post-listing-js": () => import("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/templates/blogPostListing.js" /* webpackChunkName: "component---src-templates-blog-post-listing-js" */),
  "component---src-templates-blog-post-js": () => import("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/templates/blogPost.js" /* webpackChunkName: "component---src-templates-blog-post-js" */),
  "component---src-pages-404-js": () => import("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/pages/404.js" /* webpackChunkName: "component---src-pages-404-js" */),
  "component---src-pages-index-js": () => import("/mnt/c/Users/Bay/shareddev/gatsby-blog/src/pages/index.js" /* webpackChunkName: "component---src-pages-index-js" */)
}

exports.data = () => import(/* webpackChunkName: "pages-manifest" */ "/mnt/c/Users/Bay/shareddev/gatsby-blog/.cache/data.json")

